(ns assignment4-2.core
  (:require [reagent.core :as r :refer [atom]]
            [cljs.core.async :as a]))

(enable-console-print!)

(println "Edits to this text should show up in your developer console.")

;; define your app data so that it doesn't get over-written on reload

(defonce app-state (r/atom {
                            :mode :line 
                            :lines {}
                            :circles {}
                            :rects {}
                            }))

(def history (r/atom '()))

(def mode (r/cursor app-state :mode))

(defn on-js-reload []
  ;; optionally touch your app-state to force rerendering depending on
  ;; your application
  ;; (swap! app-state update-in [:__figwheel_counter] inc)
)

(def canvas-coords {:x 10 :y 40})

(defn on-click [e]
  {:x (- (.-clientX e) (canvas-coords :x)) 
   :y (- (.-clientY e) (canvas-coords :y))})

(defn mode-select [k]
  #(reset! mode k)
  (swap! history conj app-state))

(defn move-mouse [e]
  nil)

(defn undo []
  (swap! history pop)
  (reset! app-state (first history)))

(defn main []
 [:div
    [:button {:on-click #(mode-select :line)} "Line"]
    [:button {:on-click #(mode-select :circle)} "Circle"]
    [:button {:on-click #(mode-select :rect)} "Rectangle"]
    [:button {:on-click undo} "Undo"]    
    [:div
      {:on-click #(js/alert  (on-click %))
       :on-mouse-move #()} 
      [:svg {:width 600 :height 600 :stroke "black"
            :style {:position :fixed :top (canvas-coords :y) :left (canvas-coords :x) :border "red solid 1px"}}]]
    ])

(r/render-component [main]
                          (. js/document (getElementById "app")))


